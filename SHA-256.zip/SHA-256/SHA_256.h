#include <iostream>
#include <stdint.h>
#include <inttypes.h>
#include <bits/stdc++.h>
#include <cstring>
#include <sstream>
#include <iomanip>
#include <string>
#include <array>
#include "Globals.h"
using namespace std;


//uint8_t data[64]; //uint8_t is a binary data type limiting bits to 8 per set




void Padding(unsigned char* Pass, int Size, uint8_t* data)
{

    //Converting Password to Binary

    //Binary Array for Password
    uint8_t* pass_bin = new uint8_t[Size];
    for(int i = 0; i<Size; i++)
    {
        pass_bin[i] = Pass[i];
    }

    //padding password
    //transferring password to data array
    int j = 0;
    for(int i = 0; i<Size; i++)
    {
        data[j++] = pass_bin[i]; 
    }

    data[j++] = 0x80; //Adding 1

    for(; j<63; j++)
    {
        data[j] = 0x00; //Adding 0s in the rest
    }

    data[j] = Size;
    

}

uint32_t Right_Rotate(uint32_t x, uint32_t n)
{
    return (x >> n) | (x << 32-n);
}

uint32_t S0(uint32_t x) 
{
	return Right_Rotate(x, 7) ^ Right_Rotate(x, 18) ^ (x >> 3);
}

uint32_t S1(uint32_t x) 
{
	return Right_Rotate(x, 17) ^ Right_Rotate(x, 19) ^ (x >> 10);
}

void Creating_Message_Schedual(uint32_t * data32, uint8_t* data8)
{
    //Splitting 8 bit representation data into blocks of 32 bits which will fit into the first 16 words of the new uint32_t array

    // Split data in 32 bit blocks for the first 16 words
    for (uint8_t i = 0, j = 0; i < 16; i++, j += 4) 
    { 
		data32[i] = (data8[j] << 24) | (data8[j + 1] << 16) | (data8[j + 2] << 8) | (data8[j + 3]);
	}

    // Remaining 48 blocks----Padding with 0s and Modifiying them using S0 and S1 functons
    for (uint8_t k = 16 ; k < 64; k++) 
    { 
		data32[k] = S1(data32[k - 2]) + data32[k - 7] + S0(data32[k - 15]) + data32[k - 16];
	}

}

void Compression(uint32_t* data32)
{
    uint32_t Hashes[8], s0, s1, temp1, temp2, maj, ch;
    uint32_t Hash_Change0,Hash_Change4;

    for(uint8_t i = 0; i<8; i++)
    {
        Hashes[i] = Hash_Values[i]; //Making a temprory array for already hard coded hashes to be used further
    }

    for(uint8_t i = 0; i<64; i++)
    {
        s0  = Right_Rotate(Hashes[0], 2) ^ Right_Rotate(Hashes[0], 13) ^ Right_Rotate(Hashes[0], 22);
        s1 = Right_Rotate(Hashes[4], 6) ^ Right_Rotate(Hashes[4], 11) ^ Right_Rotate(Hashes[4], 25);
        ch = (Hashes[4] & Hashes[5]) ^ (~Hashes[4] & Hashes[6]);
        maj = (Hashes[0] & (Hashes[1] | Hashes[2])) | (Hashes[1] & Hashes[2]);
        
        temp1 = Hashes[7] + s1 + ch + Round_Constants[i] + data32[i];
        temp2 = s0 + maj;

        Hash_Change0 = temp1 + temp2;
        Hash_Change4 = Hashes[3] + temp2; 

        Hashes[7] = Hashes[6];
		Hashes[6] = Hashes[5];
		Hashes[5] = Hashes[4];
		Hashes[4] = Hash_Change4;
		Hashes[3] = Hashes[2];
		Hashes[2] = Hashes[1];
		Hashes[1] = Hashes[0];
		Hashes[0] = Hash_Change0;
    }

    for(uint8_t i = 0 ; i < 8 ; i++) 
    {
        Hash_Values[i] += Hashes[i];
    }


}

void revert(uint8_t * hash) 
{
	// SHA uses big endian byte ordering
	// Revert all bytes
	for (uint8_t i = 0 ; i < 4 ; i++) 
    {
		for(uint8_t j = 0 ; j < 8 ; j++) 
        {
			hash[i + (j * 4)] = (Hash_Values[j] >> (24 - i * 8)) & 0x000000ff;
		}
	}
}

uint8_t* Digest(uint8_t* hash)
{
	revert(hash);

	return hash;
}

string toString(const uint8_t * hash) {
	std::stringstream s;
	s << std::setfill('0') << std::hex;

	for(uint8_t i = 0 ; i < 32 ; i++) {
		s << std::setw(2) << (unsigned int) hash[i];
	}

	return s.str();
}


string Hash(unsigned char* Password)
{
    uint8_t Data1[64];  //Inital 512 bit array / 64 Byte array with each byte represented with 8 bits
    uint32_t Data2[64]; //52 bit array divided into 32 bit representation for each 64 bytes
    
    Padding(Password, sizeof(Password)-1, Data1); // Padding Data to make it 512 bit
    Creating_Message_Schedual(Data2,Data1); //
    Compression(Data2);

    uint8_t * hash = new uint8_t[32];
    Digest(hash);
    string Hash = toString(hash);
    cout<<"\n\nHashed Password: "<<Hash<<endl;
    cout<<"\n";

    return Hash;
}

