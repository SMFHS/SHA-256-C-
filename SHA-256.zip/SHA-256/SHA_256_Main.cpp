#include <iostream>
#include "SHA_256.h"
using namespace std;


int main(int argc, char ** argv)
{
    unsigned char* password = (unsigned char *)argv[1]; //Input of password to be hashed
    Hash(password);
}